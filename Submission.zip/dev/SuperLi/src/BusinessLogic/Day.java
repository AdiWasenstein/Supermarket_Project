package BusinessLogic;

public enum Day {
    sunday, monday, tuesday, wednesday, thursday, friday, saturday
}
