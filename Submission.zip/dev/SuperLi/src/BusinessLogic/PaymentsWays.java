package BusinessLogic;

public enum PaymentsWays {
    direct, plus30, plus60
}
