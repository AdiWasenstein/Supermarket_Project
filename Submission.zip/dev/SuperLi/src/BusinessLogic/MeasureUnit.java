package BusinessLogic;

public enum MeasureUnit {
    UNIT,
    ML,
    GM,
    CM
}
