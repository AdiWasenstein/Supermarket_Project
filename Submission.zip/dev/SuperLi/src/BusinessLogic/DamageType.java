package BusinessLogic;

public enum DamageType {
    COVER,
    PHYSICAL,
    ELECTRICAL,
    ROTTEN,
    NONE
}
